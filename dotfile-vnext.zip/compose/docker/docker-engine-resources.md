STEP 1 — Create an Ansible role for docker_engine

Inside your project:

roles/docker_engine/
  tasks/
    main.yml


Put this in roles/docker_engine/tasks/main.yml:

---
- name: Update apt cache
  ansible.builtin.apt:
    update_cache: yes
  become: true

- name: Install required packages
  ansible.builtin.apt:
    name:
      - ca-certificates
      - curl
      - gnupg
      - lsb-release
    state: present
  become: true

- name: Install docker.io
  ansible.builtin.apt:
    name: docker.io
    state: present
  become: true

- name: Ensure docker group exists
  ansible.builtin.group:
    name: docker
    state: present
  become: true

- name: Add user to docker group
  ansible.builtin.user:
    name: "{{ ansible_user_id }}"
    groups: docker
    append: yes
  become: true

- name: Enable docker service
  ansible.builtin.systemd:
    name: docker
    enabled: true
  become: true

- name: Start docker service
  ansible.builtin.systemd:
    name: docker
    state: started
  become: true